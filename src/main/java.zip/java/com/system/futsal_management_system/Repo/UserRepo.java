package com.system.futsal_management_system.Repo;

import com.system.futsal_management_system.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepo extends JpaRepository<User, Integer> {
}
