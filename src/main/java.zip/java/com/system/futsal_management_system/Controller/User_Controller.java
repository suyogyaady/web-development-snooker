package com.system.futsal_management_system.Controller;

import com.system.futsal_management_system.Service.UserService;
import com.system.futsal_management_system.entity.User;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequiredArgsConstructor
@RequestMapping("/user")
public class User_Controller {
    private final UserService userService;
    @GetMapping("/register")
    public String getPage(){

        return "register";
    }

    @GetMapping
    public String getUserList(Model model){
        List<User> users = userService.fetchAll();
        model.addAttribute("userlist", users);
        return "User/index";
    }
}




