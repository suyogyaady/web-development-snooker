package com.system.futsal_management_system.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping
public class Login_Controller {
    @GetMapping("/login")
    public String getPage(){
        return "login";
    }



}
