package com.system.futsal_management_system.Service.Impl;

import com.system.futsal_management_system.Repo.UserRepo;
import com.system.futsal_management_system.Service.UserService;
import com.system.futsal_management_system.entity.User;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {
    private final UserRepo userRepo;
    public List<User> fetchAll() {
       return this.userRepo.findAll();

    }
}
