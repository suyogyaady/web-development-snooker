package com.system.futsal_management_system.Service;

import com.system.futsal_management_system.entity.User;

import java.util.List;

public interface UserService {
    List<User> fetchAll();

}
