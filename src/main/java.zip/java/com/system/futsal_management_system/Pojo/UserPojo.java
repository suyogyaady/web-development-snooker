package com.system.futsal_management_system.Pojo;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor

public class UserPojo {
    private Integer id;
    private String email;
    private  String mobile_no;
}
